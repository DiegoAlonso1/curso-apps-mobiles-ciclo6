package com.example.examenparcial_diegoalonsoolivera_ws7c.models

import com.google.gson.annotations.SerializedName

class ApiResponseHeader (
    @SerializedName("api")
    var api: ApiResponseDetails
)